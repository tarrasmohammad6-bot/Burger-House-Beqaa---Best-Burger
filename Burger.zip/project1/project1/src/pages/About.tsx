import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import classicBurger from '@/assets/classic-burger.jpg';

const About = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center">
            About <span className="text-primary">Burger House Bekaa</span>
          </h1>

          <div className="grid md:grid-cols-2 gap-8 items-center mb-12">
            <div>
              <img
                src={classicBurger}
                alt="Our Story"
                className="rounded-lg shadow-elevated w-full"
              />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-4">Our Story</h2>
              <p className="text-muted-foreground mb-4">
                Founded in the heart of Bekaa, Lebanon, Burger House has been serving
                the community with delicious, high-quality burgers since 2020.
              </p>
              <p className="text-muted-foreground">
                Our passion for great food and excellent service has made us a local
                favorite. We believe in using only the freshest ingredients and
                traditional cooking methods to create burgers that taste like home.
              </p>
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-8 mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Our Values</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl mb-3">🌟</div>
                <h3 className="font-bold mb-2">Quality First</h3>
                <p className="text-sm text-muted-foreground">
                  We never compromise on the quality of our ingredients or preparation.
                </p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-3">🤝</div>
                <h3 className="font-bold mb-2">Community Focus</h3>
                <p className="text-sm text-muted-foreground">
                  We're proud to be part of the Bekaa community and support local suppliers.
                </p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-3">💚</div>
                <h3 className="font-bold mb-2">Sustainability</h3>
                <p className="text-sm text-muted-foreground">
                  We care about the environment and use eco-friendly packaging.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              To deliver the best burger experience in Lebanon by combining fresh,
              quality ingredients with exceptional service and a passion for great food.
              Every burger we make is a labor of love, crafted to bring joy to your table.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default About;
