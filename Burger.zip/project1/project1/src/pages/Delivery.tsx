import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, MapPin, Phone, DollarSign } from 'lucide-react';

const Delivery = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-primary">Delivery</span> Information
            </h1>
            <p className="text-lg text-muted-foreground">
              Fast and reliable delivery service across Bekaa
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Delivery Time</h3>
                    <p className="text-muted-foreground">
                      Average delivery time: <strong className="text-foreground">25-30 minutes</strong>
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      We guarantee your food arrives hot and fresh!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <DollarSign className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Delivery Fee</h3>
                    <p className="text-muted-foreground">
                      <strong className="text-accent text-xl">FREE DELIVERY</strong>
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      No minimum order required!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Delivery Area</h3>
                    <p className="text-muted-foreground">
                      We deliver throughout <strong className="text-foreground">Bekaa, Lebanon</strong>
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Covering all major areas and neighborhoods
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Track Your Order</h3>
                    <p className="text-muted-foreground">
                      Call us at: <strong className="text-foreground">+961 8 XXX XXX</strong>
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Get real-time updates on your order
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-hero text-primary-foreground">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4 text-center">Operating Hours</h2>
              <div className="grid md:grid-cols-2 gap-4 text-center">
                <div>
                  <p className="font-bold mb-2">Monday - Friday</p>
                  <p className="opacity-90">11:00 AM - 11:00 PM</p>
                </div>
                <div>
                  <p className="font-bold mb-2">Saturday - Sunday</p>
                  <p className="opacity-90">12:00 PM - 12:00 AM</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="mt-12 bg-muted/50 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-6 text-center">How It Works</h2>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-lg">
                  1
                </div>
                <h3 className="font-bold mb-2">Browse Menu</h3>
                <p className="text-sm text-muted-foreground">
                  Choose from our delicious selection
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-lg">
                  2
                </div>
                <h3 className="font-bold mb-2">Place Order</h3>
                <p className="text-sm text-muted-foreground">
                  Add items to cart and checkout
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-lg">
                  3
                </div>
                <h3 className="font-bold mb-2">We Prepare</h3>
                <p className="text-sm text-muted-foreground">
                  Our chefs prepare your order fresh
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-lg">
                  4
                </div>
                <h3 className="font-bold mb-2">Enjoy!</h3>
                <p className="text-sm text-muted-foreground">
                  Hot food delivered to your door
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Delivery;
