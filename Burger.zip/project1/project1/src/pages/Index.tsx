import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import heroBurger from '@/assets/hero-burger.jpg';
import classicBurger from '@/assets/classic-burger.jpg';
import fries from '@/assets/fries.jpg';
import drinks from '@/assets/drinks.jpg';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroBurger}
            alt="Delicious burger"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/30" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center md:text-left max-w-2xl">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground">
            The Best Burgers in <span className="text-primary">Bekaa</span>
          </h1>
          <p className="text-xl mb-8 text-foreground/90">
            Fresh ingredients, bold flavors, and fast delivery right to your door.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <Link to="/menu/burgers">
              <Button size="lg" className="w-full sm:w-auto">
                Order Now
              </Button>
            </Link>
            <Link to="/about">
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Why Choose <span className="text-primary">Burger House</span>?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🍔</span>
              </div>
              <h3 className="font-bold text-xl mb-2">Fresh Ingredients</h3>
              <p className="text-muted-foreground">
                We use only the freshest, locally-sourced ingredients for the best taste.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🚀</span>
              </div>
              <h3 className="font-bold text-xl mb-2">Fast Delivery</h3>
              <p className="text-muted-foreground">
                Hot and fresh burgers delivered to your door in under 30 minutes.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">⭐</span>
              </div>
              <h3 className="font-bold text-xl mb-2">Premium Quality</h3>
              <p className="text-muted-foreground">
                Every burger is crafted with care and attention to detail.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Preview Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Explore Our <span className="text-primary">Menu</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Link to="/menu/burgers" className="group">
              <div className="overflow-hidden rounded-lg shadow-menu-card">
                <img
                  src={classicBurger}
                  alt="Burgers"
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="p-6 bg-card">
                  <h3 className="font-bold text-xl mb-2 group-hover:text-primary transition-colors">
                    Burgers
                  </h3>
                  <p className="text-muted-foreground">
                    From classic to gourmet, find your perfect burger.
                  </p>
                </div>
              </div>
            </Link>

            <Link to="/menu/fries" className="group">
              <div className="overflow-hidden rounded-lg shadow-menu-card">
                <img
                  src={fries}
                  alt="Fries"
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="p-6 bg-card">
                  <h3 className="font-bold text-xl mb-2 group-hover:text-primary transition-colors">
                    Fries
                  </h3>
                  <p className="text-muted-foreground">
                    Crispy, golden fries with amazing flavors.
                  </p>
                </div>
              </div>
            </Link>

            <Link to="/menu/drinks" className="group">
              <div className="overflow-hidden rounded-lg shadow-menu-card">
                <img
                  src={drinks}
                  alt="Drinks"
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="p-6 bg-card">
                  <h3 className="font-bold text-xl mb-2 group-hover:text-primary transition-colors">
                    Drinks
                  </h3>
                  <p className="text-muted-foreground">
                    Refresh yourself with our cold beverages.
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-hero text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Order?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Get your favorite burgers delivered hot and fresh!
          </p>
          <Link to="/menu/burgers">
            <Button size="lg" variant="secondary">
              View Full Menu
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
