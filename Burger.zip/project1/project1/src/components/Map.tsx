import { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

const Map = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current) return;

    // Initialize map centered on Bekaa, Lebanon
    mapboxgl.accessToken = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [35.9, 33.85], // Bekaa Valley coordinates
      zoom: 10,
    });

    // Add navigation controls
    map.current.addControl(
      new mapboxgl.NavigationControl(),
      'top-right'
    );

    // Add marker for restaurant location
    new mapboxgl.Marker({ color: '#d97706' })
      .setLngLat([35.9, 33.85])
      .setPopup(
        new mapboxgl.Popup({ offset: 25 })
          .setHTML('<h3 style="margin: 0; padding: 0; font-weight: bold;">Burger House Bekaa</h3><p style="margin: 5px 0 0 0;">Best burgers in Bekaa!</p>')
      )
      .addTo(map.current);

    // Cleanup
    return () => {
      map.current?.remove();
    };
  }, []);

  return (
    <div className="relative w-full h-[400px] rounded-lg overflow-hidden shadow-elevated">
      <div ref={mapContainer} className="absolute inset-0" />
    </div>
  );
};

export default Map;
