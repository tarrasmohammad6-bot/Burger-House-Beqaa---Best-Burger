import classicBurger from '@/assets/classic-burger.jpg';
import cheeseBurger from '@/assets/cheese-burger.jpg';
import baconBurger from '@/assets/bacon-burger.jpg';
import doubleBurger from '@/assets/double-burger.jpg';
import mushroomBurger from '@/assets/mushroom-burger.jpg';
import spicyBurger from '@/assets/spicy-burger.jpg';
import veggieBurger from '@/assets/veggie-burger.jpg';
import chickenBurger from '@/assets/chicken-burger.jpg';
import regularFries from '@/assets/regular-fries.jpg';
import largeFries from '@/assets/large-fries.jpg';
import cheeseFries from '@/assets/cheese-fries.jpg';
import loadedFries from '@/assets/loaded-fries.jpg';
import sweetPotatoFries from '@/assets/sweet-potato-fries.jpg';
import cajunFries from '@/assets/cajun-fries.jpg';
import cocaCola from '@/assets/coca-cola.jpg';
import sprite from '@/assets/sprite.jpg';
import fanta from '@/assets/fanta.jpg';
import water from '@/assets/water.jpg';
import icedTea from '@/assets/iced-tea.jpg';
import lemonade from '@/assets/lemonade.jpg';
import vanillaMilkshake from '@/assets/vanilla-milkshake.jpg';
import chocolateMilkshake from '@/assets/chocolate-milkshake.jpg';
import strawberryMilkshake from '@/assets/strawberry-milkshake.jpg';

export const burgersMenu = [
  {
    id: 'classic-burger',
    name: 'Classic Burger',
    description: 'Juicy beef patty, lettuce, tomato, onion, pickles, and our special sauce',
    price: 8.99,
    category: 'burger' as const,
    image: classicBurger,
  },
  {
    id: 'cheese-burger',
    name: 'Cheese Burger',
    description: 'Classic burger with melted cheddar cheese',
    price: 9.99,
    category: 'burger' as const,
    image: cheeseBurger,
  },
  {
    id: 'bacon-burger',
    name: 'Bacon Burger',
    description: 'Beef patty with crispy bacon, cheese, and BBQ sauce',
    price: 11.99,
    category: 'burger' as const,
    image: baconBurger,
  },
  {
    id: 'double-burger',
    name: 'Double Burger',
    description: 'Two beef patties, double cheese, and all the toppings',
    price: 13.99,
    category: 'burger' as const,
    image: doubleBurger,
  },
  {
    id: 'mushroom-burger',
    name: 'Mushroom Swiss Burger',
    description: 'Sautéed mushrooms, Swiss cheese, and garlic aioli',
    price: 10.99,
    category: 'burger' as const,
    image: mushroomBurger,
  },
  {
    id: 'spicy-burger',
    name: 'Spicy Jalapeño Burger',
    description: 'Beef patty with jalapeños, pepper jack cheese, and spicy mayo',
    price: 10.99,
    category: 'burger' as const,
    image: spicyBurger,
  },
  {
    id: 'veggie-burger',
    name: 'Veggie Burger',
    description: 'Plant-based patty with fresh vegetables and special sauce',
    price: 9.99,
    category: 'burger' as const,
    image: veggieBurger,
  },
  {
    id: 'chicken-burger',
    name: 'Crispy Chicken Burger',
    description: 'Breaded chicken breast, lettuce, tomato, and mayo',
    price: 9.99,
    category: 'burger' as const,
    image: chickenBurger,
  },
];

export const friesMenu = [
  {
    id: 'regular-fries',
    name: 'Regular Fries',
    description: 'Crispy golden french fries with a touch of salt',
    price: 3.99,
    category: 'fries' as const,
    image: regularFries,
  },
  {
    id: 'large-fries',
    name: 'Large Fries',
    description: 'Extra portion of our crispy golden fries',
    price: 5.99,
    category: 'fries' as const,
    image: largeFries,
  },
  {
    id: 'cheese-fries',
    name: 'Cheese Fries',
    description: 'Fries topped with melted cheddar cheese sauce',
    price: 6.99,
    category: 'fries' as const,
    image: cheeseFries,
  },
  {
    id: 'loaded-fries',
    name: 'Loaded Fries',
    description: 'Fries with cheese, bacon bits, and sour cream',
    price: 8.99,
    category: 'fries' as const,
    image: loadedFries,
  },
  {
    id: 'sweet-potato-fries',
    name: 'Sweet Potato Fries',
    description: 'Crispy sweet potato fries with honey mustard',
    price: 5.99,
    category: 'fries' as const,
    image: sweetPotatoFries,
  },
  {
    id: 'cajun-fries',
    name: 'Cajun Fries',
    description: 'Spicy fries seasoned with Cajun spices',
    price: 5.99,
    category: 'fries' as const,
    image: cajunFries,
  },
];

export const drinksMenu = [
  {
    id: 'coca-cola',
    name: 'Coca Cola',
    description: 'Classic Coca Cola - 330ml',
    price: 2.50,
    category: 'drink' as const,
    image: cocaCola,
  },
  {
    id: 'sprite',
    name: 'Sprite',
    description: 'Refreshing lemon-lime soda - 330ml',
    price: 2.50,
    category: 'drink' as const,
    image: sprite,
  },
  {
    id: 'fanta',
    name: 'Fanta Orange',
    description: 'Orange flavored soda - 330ml',
    price: 2.50,
    category: 'drink' as const,
    image: fanta,
  },
  {
    id: 'water',
    name: 'Mineral Water',
    description: 'Fresh mineral water - 500ml',
    price: 1.99,
    category: 'drink' as const,
    image: water,
  },
  {
    id: 'iced-tea',
    name: 'Iced Tea',
    description: 'Refreshing peach iced tea - 330ml',
    price: 2.99,
    category: 'drink' as const,
    image: icedTea,
  },
  {
    id: 'lemonade',
    name: 'Fresh Lemonade',
    description: 'Homemade fresh lemonade - 400ml',
    price: 3.50,
    category: 'drink' as const,
    image: lemonade,
  },
  {
    id: 'milkshake-vanilla',
    name: 'Vanilla Milkshake',
    description: 'Creamy vanilla milkshake - 400ml',
    price: 4.99,
    category: 'drink' as const,
    image: vanillaMilkshake,
  },
  {
    id: 'milkshake-chocolate',
    name: 'Chocolate Milkshake',
    description: 'Rich chocolate milkshake - 400ml',
    price: 4.99,
    category: 'drink' as const,
    image: chocolateMilkshake,
  },
  {
    id: 'milkshake-strawberry',
    name: 'Strawberry Milkshake',
    description: 'Fresh strawberry milkshake - 400ml',
    price: 4.99,
    category: 'drink' as const,
    image: strawberryMilkshake,
  },
];
